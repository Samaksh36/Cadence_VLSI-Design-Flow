Core Utilization: 
The values given to the floorplanning command was changed for different core utilizations.

TCL Scripts:
Contains all the TCL commands that were used in the making of the project.
It is divided into multiple TCL scripts, for different stages of the Design flow.
Designinit.tcl: Creates & initilizes the project
DoFloorplanning.tcl: Performs floorplanning & placement of standard cells
DoCTS.tcl: performs the Clock Tree Synthesis
DoRouting.tcl: Performs the detail routing & generates the gds file

LEF File Used: 
gsclib090_translated_ref.lef

